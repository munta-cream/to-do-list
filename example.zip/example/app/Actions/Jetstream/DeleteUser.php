<?php

namespace App\Actions\Jetstream;

use Laravel\Jetstream\Contracts\DeletesUsers;

class DeleteUser implements DeletesUsers
{
    /**
     * 
     *
     * @param  mixed  $user
     * @return void
     */
    public function delete($user)
    {
        $user->delete();
    }
}
